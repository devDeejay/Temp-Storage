import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'mob-component',
    templateUrl: 'mob-component.component.html',
    styleUrls: ['mob-component.component.scss']
})
export class MobComponentComponent {

}
