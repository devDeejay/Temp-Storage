// Angular Imports
import { NgModule } from '@angular/core';

// This Module's Components
import { MobileComponentComponent } from './mobile-component.component';

@NgModule({
    imports: [

    ],
    declarations: [
        MobileComponentComponent,
    ],
    exports: [
        MobileComponentComponent,
    ]
})
export class MobileComponentModule {

}
