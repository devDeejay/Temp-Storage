import { Component, Input } from '@angular/core';

@Component({
    
    selector: 'my-tag',
    templateUrl: 'mobile-component-ts.component.html'
    
})
export class MobileComponentClass {
    title = 'Mobile Component';
    feedback='hello';
    backgroundcolor = 'black';
    textColor = 'white';
}
