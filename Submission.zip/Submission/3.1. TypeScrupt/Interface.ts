interface Flight {
	flightId : string;
	flightNumber : number;
	flightType : string;
	flightName : string;
	
}