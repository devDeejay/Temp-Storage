package controller;

// ======================================
//= 		loginController.java	 	=
//= 	Created By Dhananjay Trivedi 	=
//= 	adm-in-tvinayag corp@123	 	=
//= 		 On 29 / 08 / 2018 		    =
// ======================================

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class loginController
 */
@WebServlet("/loginController")
public class loginController extends HttpServlet {

	PrintWriter out;

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public loginController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		// Setting Out Writer
		out = response.getWriter();
		response.setContentType("text/html");
		out.println("<html><head><title>Controller Page</title></head>");

		try {

			String username = request.getParameter("username");
			String password = request.getParameter("password");

			// Checking For Valid Credentials
			if ("admin".equals(username) && "admin".equals(password)) {
				out.println("<body><h1>Ready To Create Session</h1></body>");

				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Date date = new Date(System.currentTimeMillis());

				// Create Session
				HttpSession session = request.getSession();
				session.setAttribute("username", username); // Storing Username
															// in session
				session.setAttribute("date", dateFormat.format(date));

				// TODO: Store Name and Today's Date

				// Goto Success.jsp
				RequestDispatcher rd = request
						.getRequestDispatcher("Success.jsp");
				rd.forward(request, response);

			} else {
				out.println("<body><h1>Please enter Correct Credentials</h1></body>");
			}
			
		} catch (Exception e) {
			// TODO: Exception Handling
			out.println("<body><h1>Something Went Wrong On Servers</h1></body>");
		}
		out.println("</html>");
	}

}
