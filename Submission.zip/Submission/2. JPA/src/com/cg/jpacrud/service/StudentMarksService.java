package com.cg.jpacrud.service;

import com.cg.jpacrud.entities.StudentMarks;;

public interface StudentMarksService {

	public abstract void addStudentMarks(StudentMarks student);
}