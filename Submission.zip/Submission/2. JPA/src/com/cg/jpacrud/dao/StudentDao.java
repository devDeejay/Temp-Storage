package com.cg.jpacrud.dao;

import com.cg.jpacrud.entities.StudentMarks;

public interface StudentDao {

	public abstract void addStudent(StudentMarks student);

	public abstract void commitTransaction();

	public abstract void beginTransaction();

}