package com.cg.jpacrud.entities;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trainee_Details")
public class StudentMarks implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private int detailsID;

	@Column(name = "trainee_name")
	private String traineeName;

	@Column(name = "module_name")
	private String moduleName;

	@Column(name = "mtt_marks")
	private int mttMarks;

	@Column(name = "Mpt_marks")
	private int mptMarks;

	@Column(name = "assignment_marks")
	private int assingmentMarks;
	
	@Column(name = "total")
	private int totalMarks;
	
	public StudentMarks() {
		// TODO Auto-generated constructor stub
	}

	public int getDetailsID() {
		return detailsID;
	}

	public void setDetailsID(int detailsID) {
		this.detailsID = detailsID;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public int getMttMarks() {
		return mttMarks;
	}

	public void setMttMarks(int mttMarks) {
		this.mttMarks = mttMarks;
	}

	public int getMptMarks() {
		return mptMarks;
	}

	public void setMptMarks(int mptMarks) {
		this.mptMarks = mptMarks;
	}

	public int getAssingmentMarks() {
		return assingmentMarks;
	}

	public void setAssingmentMarks(int assingmentMarks) {
		this.assingmentMarks = assingmentMarks;
	}

	public int getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
