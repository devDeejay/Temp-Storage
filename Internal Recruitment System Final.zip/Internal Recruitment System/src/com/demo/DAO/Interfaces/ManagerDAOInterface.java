package com.demo.DAO.Interfaces;

import com.demo.Model.RequisitionRequest;
import com.demo.Model.RequisitionSuggestions;

import java.util.ArrayList;

public interface ManagerDAOInterface {

    /*
     *   Raise Requisition Requests For Concerned People.
     *   View All The Suggestions Made By ExecutiveDAOInterface.
     *   Accept / Reject The Suggested Resources Against Requisitions.
     *   If Accepted, Update The Project Status For Project ID, UserID.
     *   Manually Update The Project Name, Code.
     *   Generate Reports For Pending As Well As Closed Requests of his projects.
     */

    int raiseRequisitionRequestInDatabase(RequisitionRequest request);

    ArrayList<RequisitionSuggestions> viewSuggestionsMadeByExecutiveFromDatabase(int managerID, int suggestionCode);

    ArrayList<RequisitionRequest> viewAllRequestsMade(int managerID, int choice);

    boolean acceptRejectSuggestionsInDatabase(int managerID, int requisitionIDToAcceptReject, int acceptRejectCode);

    boolean assignProjectToEmployee(int managerID, int empID);
}
