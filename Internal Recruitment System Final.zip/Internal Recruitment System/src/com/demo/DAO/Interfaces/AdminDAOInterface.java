package com.demo.DAO.Interfaces;

import com.demo.Model.User;

import java.util.ArrayList;

public interface AdminDAOInterface {

    // Show Users From Database

    ArrayList<User> viewUsersInDatabase();

    // Add Users To Database

    boolean addUserToDatabase (User userToBeAdded);

    // Modify Users In Database

    boolean modifyUserFromDatabase (User userToBeModified);

    // Delete Users From Database

    boolean deleteUserFromDatabase (User userToBeDeleted);

}
