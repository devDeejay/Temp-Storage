package com.demo.DAO.Interfaces;

import com.demo.Model.Employee;
import com.demo.Model.RequisitionRequest;
import com.demo.Model.User;

import java.util.ArrayList;

public interface ExecutiveDAOInterface {

    //  Search Employee By ID.

    Employee searchEmployeeByIDFromDatabase(int id);

    //    Search Employee By Domain.

    ArrayList<Employee> searchEmployeeByDomainFromDatabase(String domainName);

    //    Search Employee By Experience.

    ArrayList<Employee> searchEmployeeByExperienceFromDatabase(int yearsOfExperience);

    //    Search Employee By Skills.

    ArrayList<Employee> searchEmployeeBySkillsFromDatabase(String skills);

    //    Assign RMG Project To Employee.

    boolean assignProjectToManagerFromDatabase(int executiveID, int managerID);

    //    View All Requisition Requests.

    ArrayList<RequisitionRequest> viewAllOpenRequisitionRequestsFromDatabase(int executiveID, int requestCode, java.sql.Date date);

    //   Give Suggestions

    boolean giveSuggestion(int executiveID, int requestID, String combineEmployeeID);

    //   View All Unallocated Managers From Database

    ArrayList<User> viewAllUnallocatedManagersFromDatabase(int executiveID);
}
