package com.demo.DAO.Implementation;

import com.demo.DAO.Interfaces.AdminDAOInterface;
import com.demo.Exceptions.UserException;
import com.demo.Model.User;
import com.demo.Util.DBUtil;
import com.demo.Util.IClientQueryMapper;
import com.demo.Util.Log;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AdminDAOImplementation implements AdminDAOInterface {

    private static final String TAG = "AdminDAO : ";
    //All Working, Validation of Data Still Left

    @Override
    public boolean addUserToDatabase(User userToBeAdded) {

        Log.i(TAG, "Adding User To Database");
        boolean returnStatus = false;

        String username = userToBeAdded.getUsername();
        String name = userToBeAdded.getName();
        String password = userToBeAdded.getPassword();
        int userGrade = userToBeAdded.getUserGrade();

        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.ADD_USER_TO_DATABASE_QUERY);
            preparedStatement.setInt(1, userGrade);
            preparedStatement.setString(2, username);
            preparedStatement.setString(3, password);
            preparedStatement.setString(4, name);

            int status = preparedStatement.executeUpdate();

            if (status == 1) {
                Log.i(TAG, "Added User To Database");
                returnStatus = true;
            } else {
                //Log
                Log.i(TAG, "Not Adding To Database");
                return false;
            }

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something went wrong while adding user to Database");
            } catch (UserException e1) {
                Log.e(TAG, "Exception Occurred While Adding");
            }
        }
        return returnStatus;
    }

    @Override
    public ArrayList<User> viewUsersInDatabase() {

        Log.i(TAG, "Viewing Users From Database");
        ArrayList<User> listOfUsers = new ArrayList<>();

        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.VIEW_USERS_IN_DATABASE);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                User.Builder builder = new User.Builder();
                builder
                        .userID(resultSet.getInt("user_id"))
                        .name(resultSet.getString("name"))
                        .username(resultSet.getString("username"))
                        .userGrade(resultSet.getInt("user_grade"))
                        .password(resultSet.getString("username"));
                User user = builder.build();

                listOfUsers.add(user);
            }

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something went wrong while getting users from Database");
            } catch (UserException e1) {
                Log.e(TAG, "Exception Occurred While Viewing");
            }
        }

        Log.i(TAG, "Viewing Done From Database");
        return listOfUsers;
    }

    @Override
    public boolean modifyUserFromDatabase(User userToBeModified) {

        boolean returnStatus = false;

        Log.i(TAG, "Modifying User In Database");

        String username = userToBeModified.getUsername();
        String name = userToBeModified.getName();
        String password = userToBeModified.getPassword();
        int userGrade = userToBeModified.getUserGrade();
        int userID = userToBeModified.getUserID();

        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.UPDATE_USER_IN_DATABASE);

            preparedStatement.setInt(1, userGrade);
            preparedStatement.setString(2, username);
            preparedStatement.setString(3, password);
            preparedStatement.setString(4, name);
            preparedStatement.setInt(5, userID);

            int status = preparedStatement.executeUpdate();

            if (status == 1) {
                returnStatus = true;
                Log.i(TAG, "Modifying User In Database Done");
            } else {
                //Log
                return false;
            }

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something went wrong while modifying user in Database");
            } catch (UserException e1) {
                Log.e(TAG, "Exception Occurred While Modifying");
            }
        }
        return returnStatus;
    }

    @Override
    public boolean deleteUserFromDatabase(User userToBeDeleted) {

        Log.i(TAG, "Deleting User In Database");
        int id = userToBeDeleted.getUserID();

        boolean returnStatus = false;

        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.DELETE_USER_FROM_DATABASE);

            preparedStatement.setInt(1, id);

            int status = preparedStatement.executeUpdate();

            if (status == 1) {
                returnStatus = true;
                Log.i(TAG, "Deleting User In Database Done");
            } else {
                System.out.println("Something Went Wrong While Deleting");
            }

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something went wrong while deleting user from Database");
            } catch (UserException e1) {
                Log.e(TAG, "Exception Occurred While Deleting");
            }
        }
        return returnStatus;
    }

}
