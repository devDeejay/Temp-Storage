package com.demo.DAO.Implementation;

import com.demo.DAO.Interfaces.ExecutiveDAOInterface;
import com.demo.Exceptions.UserException;
import com.demo.Model.Employee;
import com.demo.Model.RequisitionRequest;
import com.demo.Model.RequisitionSuggestions;
import com.demo.Model.User;
import com.demo.Util.DBUtil;
import com.demo.Util.IClientQueryMapper;
import com.demo.Util.IRSValues;
import com.demo.Util.Log;

import java.sql.*;
import java.util.ArrayList;

public class ExecutiveDAOImplementation implements ExecutiveDAOInterface {

    private static final String TAG = "Executive DAO : ";

    @Override
    public Employee searchEmployeeByIDFromDatabase(int ID) {

        Log.i(TAG, "Searching Employee By ID in Database");

        // We will be returning a single Employee Object
        Employee employee = null;

        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.SEARCH_EMPLOYEE_BY_ID);

            // Getting Requests Made By Logged In Manager
            preparedStatement.setInt(1, ID);

            // Executing Query
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // Building The Employee Object
                employee = getEmployeeObjectFromResultSet(resultSet);

                Log.i(TAG, "Searching Employee By ID in Database Done");
            }

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something Went Wrong While Searching For Employee");
            } catch (UserException e1) {
                Log.e(TAG, "Exception Occurred While Searching By ID");
                return null;
            }
        }

        // Employee Will Either be returned as Object or Null if it the query fails
        return employee;
    }

    private Employee getEmployeeObjectFromResultSet(ResultSet resultSet) throws SQLException {
        Employee.Builder builder = new Employee.Builder();

        builder.employeeDomain(resultSet.getString("emp_domain"))
                .employeeID(resultSet.getInt("emp_id"))
                .employeeName(resultSet.getString("emp_name"))
                .employeeProjectID(resultSet.getInt("emp_project_id"))
                .employeeSkills(resultSet.getString("emp_skills"))
                .yearsOfExperience(resultSet.getInt("emp_experience_years"))
                .employeeStatus(resultSet.getInt("emp_allocation_status"));

        // Creating The Employee Object
        Employee employee = builder.build();
        System.out.println(employee.getEmployeeSkills() + "555");
        return employee;
    }

    @Override
    public ArrayList<Employee> searchEmployeeByDomainFromDatabase(String domainName) {
        ArrayList<Employee> employees = new ArrayList<>();

        Log.i(TAG, "Searching Employee By Domain in Database");
        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.SEARCH_EMPLOYEE_BY_DOMAIN);

            // Getting Requests Made By Logged In Manager
            preparedStatement.setString(1, domainName);

            // Executing Query
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Employee employee = getEmployeeObjectFromResultSet(resultSet);
                employees.add(employee);

                Log.i(TAG, "Searching Employee By Domain in Database Done");
            }

        } catch (Exception e) {
            try {
                Log.e(TAG, "Exception Occurred When Searching Employee By Domain in Database");
                throw new UserException(e.getMessage(), "Something Went Wrong While Searching For Employee");
            } catch (UserException e1) {
                return null;
            }
        }

        // Employees Will Either be returned as Array list or Null if it the query fails

        return employees;
    }

    @Override
    public ArrayList<Employee> searchEmployeeByExperienceFromDatabase(int yearsOfExperience) {
        ArrayList<Employee> employees = new ArrayList<>();
        Log.i(TAG, "Searching Employee By Experience in Database");
        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.SEARCH_EMPLOYEE_BY_EXPERIENCE);

            // Getting Requests Made By Logged In Manager
            preparedStatement.setInt(1, yearsOfExperience);

            // Executing Query
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Employee employee = getEmployeeObjectFromResultSet(resultSet);
                employees.add(employee);

            }

            Log.i(TAG, "Searching Employee By Experience in Database Done");

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something Went Wrong While Searching For Employee");
            } catch (UserException e1) {
                Log.e(TAG, "Exception When Searching Employee By Experience in Database");
                return null;
            }
        }

        // Employees Will Either be returned as Array list or Null if it the query fails
        return employees;
    }

    @Override
    public ArrayList<Employee> searchEmployeeBySkillsFromDatabase(String skills) {
        ArrayList<Employee> employees = new ArrayList<>();
        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.SEARCH_EMPLOYEE_BY_SKILLS);

            // Getting Requests Made By Logged In Manager
            preparedStatement.setString(1, skills);

            // Executing Query
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Employee employee = getEmployeeObjectFromResultSet(resultSet);
                employees.add(employee);
            }

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something Went Wrong While Searching For Employee");
            } catch (UserException e1) {
                return null;
            }
        }

        // Employees Will Either be returned as Array list or Null if it the query fails

        return employees;
    }

    @Override
    public boolean assignProjectToManagerFromDatabase(int executiveID, int managerID) {
        DBUtil dbUtilInstance = DBUtil.getInstance();

        int projectID = 0;

        try {
            Connection connection = dbUtilInstance.getConnection();
            PreparedStatement statement = connection.prepareStatement(IClientQueryMapper.GET_PROJECT_ID_FOR_EXECUTIVE);

            statement.setInt(1, executiveID);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                projectID = resultSet.getInt(1);
            } else {
                System.out.println("This Executive Has No Projects");
                return false;
            }

            //Second Part Of Query
            statement = connection.prepareStatement(IClientQueryMapper.UPDATE_MANAGER_ALLOCATION);

            statement.setInt(1, managerID);
            statement.setInt(2, projectID);
            statement.setInt(3, executiveID);

            int status = statement.executeUpdate();

            if (status == 1) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            try {
                throw new UserException(e.getMessage(), "Something Went Wrong While Assigning Project To Manager");
            } catch (UserException e1) {
                return false;
            }
        }
    }

    @Override
    public ArrayList<RequisitionRequest> viewAllOpenRequisitionRequestsFromDatabase(int executiveID, int requestCode, Date date) {

        ArrayList<RequisitionRequest> listOfRequests = new ArrayList<>();

        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.VIEW_ALL_OPEN_REQUESTS_FOR_EXECUTIVE);

            // Getting Requests Made For This Executive
            preparedStatement.setInt(1, executiveID);
            preparedStatement.setInt(2, requestCode);
            preparedStatement.setString(3, date.toString());

            System.out.println(executiveID + " " + requestCode + " " + date);

            // Executing Query
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                //  Getting Request Object From Result Set
                RequisitionRequest request = getRequestObjectFromResultSet(resultSet);
                listOfRequests.add(request);

            }

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something Went Wrong While Getting Requests From Database");
            } catch (UserException e1) {
                return null;
            }
        }

        return listOfRequests;
    }

    @Override
    public boolean giveSuggestion(int executiveID, int requestID, String combineEmployeeID) {
        RequisitionRequest request = null;
        RequisitionSuggestions suggestion = null;

        // Get The Request Object From Database
        try {
            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.VIEW_REQUESTS_FOR_EXECUTIVE);

            preparedStatement.setInt(1, requestID);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {

                // Get its Properties
                RequisitionRequest.Builder builder = new RequisitionRequest.Builder();

                builder.resourceManagerID(resultSet.getInt("requesting_manager_id"))
                        .requsitionID(resultSet.getInt("requisition_request_id"))
                        .projectID(resultSet.getInt("requesting_project_id"))
                        .requestStatus(resultSet.getInt("request_status"));

                request = builder.build();

            } else {
                // No Request Was Found
                System.out.println("No Open Requisition Request Found For This Requisition ID");
                return false;
            }

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something Went Wrong While looking up your request ID");
            } catch (UserException e1) {
                return false;
            }
        }


        if (request != null) {
            // Making Suggestion Object
            RequisitionSuggestions.Builder builder = new RequisitionSuggestions.Builder();
            builder
                    .requisitionRequestID(request.getRequsitionID())
                    .suggestedEmployeeID(combineEmployeeID)
                    .suggestedProjectID(request.getProjectID())
                    .suggestionStatus(IRSValues.REQUISITION_SUGGESTION_SUGGESTED)
                    .executiveID(executiveID)
                    .managerID(request.getResourceManagerID());

            // Build Suggestion Object
            suggestion = builder.build();
        }

        if (suggestion != null) {
            try {

                DBUtil dbUtilInstance = DBUtil.getInstance();
                Connection connection = dbUtilInstance.getConnection();

                PreparedStatement preparedStatement = connection
                        .prepareStatement(IClientQueryMapper.INSERT_NEW_SUGGESTIONS);

                preparedStatement.setInt(1, suggestion.getRequisitionRequestID());
                preparedStatement.setInt(2, suggestion.getSuggestedProjectID());
                preparedStatement.setInt(3, suggestion.getExecutiveID());
                preparedStatement.setInt(4, suggestion.getManagerID());
                preparedStatement.setString(5, suggestion.getSuggestedEmployeeID());
                preparedStatement.setInt(6, suggestion.getSuggestionStatus());

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected == 1) {
                    return true;
                } else {
                    return false;
                }

            } catch (Exception e) {
                try {
                    throw new UserException(e.getMessage(), "Exception While Raising Suggestion");
                } catch (UserException e1) {
                    Log.e(TAG, "Exception At Generating Suggestions");
                    return false;
                }
            }
        }
        return false;
    }

    private RequisitionRequest getRequestObjectFromResultSet(ResultSet resultSet) throws SQLException {
        RequisitionRequest.Builder builder = new RequisitionRequest.Builder();

        builder.resourceManagerID(resultSet.getInt("requesting_manager_id"))
                .requsitionID(resultSet.getInt("requisition_request_id"))
                .projectID(resultSet.getInt("requesting_project_id"))
                .requestStatus(resultSet.getInt("request_status"))
                .vacancy(resultSet.getInt("vacancy"))
                .numberOfPeopleRequired(resultSet.getInt("required"))
                .skillsAsString(resultSet.getString("skills_required"))
                .domainName(resultSet.getString("domain"))
                .dateCreated(resultSet.getDate("request_open_date"))
                .dateClosed(resultSet.getDate("request_close_date"));

        RequisitionRequest request = builder.build();

        return request;

    }

    public ArrayList<User> viewAllUnallocatedManagersFromDatabase(int executiveID) {

        Log.i(TAG, "Viewing Unallocated Managers From DB");
        ArrayList<User> listOfUnallocatedManagers = new ArrayList<>();

        try {

            DBUtil dbUtilInstance = DBUtil.getInstance();
            Connection connection = dbUtilInstance.getConnection();

            PreparedStatement preparedStatement = connection
                    .prepareStatement(IClientQueryMapper.VIEW_ALL_MANAGERS_FROM_DATABASE);

            // Executing Query
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                //  Getting Request Object From Result Set

                User.Builder builder = new User.Builder();
                builder.userID(resultSet.getInt(1));
                builder.name(resultSet.getString(2));

                // Build Suggestion Object
                User user = builder.build();
                listOfUnallocatedManagers.add(user);
            }

            Log.i(TAG, "Done Viewing Unallocated Managers From DB");

        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Something Went Wrong While Getting Lists Of All Managers From Database");
            } catch (UserException e1) {
                listOfUnallocatedManagers = null;
                Log.e(TAG, "Exception When Viewing Unallocated Managers From DB");
            }
        }

        return listOfUnallocatedManagers;
    }
}
