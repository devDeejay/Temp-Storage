package com.demo.Util;

import org.apache.log4j.Logger;
/**
 * The class provides custom implementation of Loggers.
 * @version 0.1 Beta
 * @author Utkarsh Trehan
 */
public class Log {
	
	static Logger log=Logger.getRootLogger();
	
	//Info-Logger
	public static void i(String context, String message)
	{
		log.info(context+"	"+message);
	}
	//Error-Logger
	public static void e(String context, String message)
	{
		log.error(context+"	"+message);
	}
	
}
