package com.demo.UI;

import com.demo.Model.Employee;
import com.demo.Model.RequisitionRequest;
import com.demo.Model.User;
import com.demo.Service.Implementation.ExecutiveServiceImplementation;
import com.demo.Util.IRSValues;
import com.demo.Util.Log;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;


public class ExecutiveUI {
    private static final String TAG = "ExecutiveUI : ";
    // ===================================================================
    // =                                                                 =
    // =          2. When User is Logged In As Resource Manager          =
    // =                                                                 =
    // ===================================================================

    static void loginAsExecutive(User loggedInUser) {

        StartUI.printSymbols();

        StartUI.greetUser(loggedInUser);
        int executiveID = loggedInUser.getUserID();

        System.out.println("Please Press 1 To View All Open Requisition Requests");
        System.out.println("Please Press 2 To Give Suggestions For Requests");
        System.out.println("Please Press 3 To Search Employee");
        System.out.println("Please Press 4 To Assign Project To Manager");
        System.out.println("Please Press 5 To Generate Reports");
        System.out.println("Please Press -1 To Logout");

        ExecutiveServiceImplementation executiveService = new ExecutiveServiceImplementation();

        String rmgInput = StartUI.getInputFromBufferedReader();

        switch (rmgInput) {
            case "1":
                //    View All Open Requisition Requests.
                Log.i(TAG, "View All Requests");
                viewAllRequisitionRequests(executiveService, executiveID);
                break;

            case "2":
                //    Generate Suggestions.
                Log.i(TAG, "Give Suggestions");
                giveSuggestionForRequest(executiveService, executiveID);
                break;

            case "3":
                //    Search Employee On Domain / Skill / Experience / ID.
                Log.i(TAG, "Search User");
                searchEmployee(executiveService);
                break;

            case "4":

                //    Assign Project To Manager.
                Log.i(TAG, "Assign Project To Manager");
                assignProjectToManager(executiveService, executiveID);
                break;

            case "5":
                //    Generate Reports For Closed / Pending Requests from all Resource Managers for specific Date / Time / Closed / Pending.
                generateReports(executiveService, executiveID);
                Log.i(TAG, "Generate Reports");
                break;

            case "-1":
                return;

            default:
                System.out.println("Incorrect Input, Try Again");
        }
        loginAsExecutive(loggedInUser);
    }

    // ================================================================
    // =      				RMG Executive Methods     				  =
    // ================================================================

    //  3.1 - Search Employee

    private static void searchEmployee(ExecutiveServiceImplementation executiveService) {

        System.out.println("*****   Search Employee    *****\n");

        System.out.println("Press 1 To Search By ID");
        System.out.println("Press 2 To Search By Domain");
        System.out.println("Press 3 To Search By Experience");
        System.out.println("Press 4 To Search By Skills");
        System.out.println("Press -1 To Go Back To Previous Menu");

        String executiveInput = StartUI.getInputFromBufferedReader();

        switch (executiveInput) {

            case "1":
                Log.i(TAG, "Search Employee By ID");
                searchEmployeeByID(executiveService);
                break;

            case "2":
                Log.i(TAG, "Search Employee By Domain");
                searchEmployeeByDomain(executiveService);
                break;

            case "3":
                Log.i(TAG, "Search Employee By Experience");
                searchEmployeeByExperience(executiveService);
                break;

            case "4":
                Log.i(TAG, "Search Employee By Skills");
                searchEmployeeBySkills(executiveService);
                break;

            case "-1":
                return;

            default:
                System.out.println("Please enter valid input");
                break;
        }
        searchEmployee(executiveService);
    }

    private static void searchEmployeeBySkills(ExecutiveServiceImplementation executiveService) {
        String skills = StartUI.getInputFromBufferedReader();
        ArrayList<Employee> list = executiveService.searchEmployeeBySkills(skills);
        printListOfEmployee(list);
    }

    private static void searchEmployeeByExperience(ExecutiveServiceImplementation executiveService) {
        System.out.println("Enter The Minimum Number Of Years of Experience");

        int yearsOfExperience = StartUI.getAValidNumberFromUser("Enter A Valid Number Of Years");
        if (yearsOfExperience < 0) {
            System.out.println("Experience Cannot Be Negative");
            return;
        }

        ArrayList<Employee> list = executiveService.searchEmployeeByExperience(yearsOfExperience);
        printListOfEmployee(list);
    }

    //  3.1.1 - Search Employee By Domain
    private static void searchEmployeeByDomain(ExecutiveServiceImplementation executiveService) {

        System.out.println("Enter The Domain Of Employee");

        String domainName = StartUI.getInputFromBufferedReader();
        if (domainName.equals("-1")) {
            return;
        }
        ArrayList<Employee> listOfEmployees = executiveService.searchEmployeeByDomain(domainName);
        printListOfEmployee(listOfEmployees);
    }

    private static void printListOfEmployee(ArrayList<Employee> listOfEmployees) {

        if (listOfEmployees == null) {
            System.out.println("No Employees Found For This Domain");
            return;
        }
        Iterator<Employee> iterator = listOfEmployees.iterator();

        while (iterator.hasNext()) {
            Employee e = iterator.next();
            printEmployeeObject(e);
        }
    }

    //  3.1.2 - Search Employee By ID
    private static void searchEmployeeByID(ExecutiveServiceImplementation executiveService) {

        System.out.println("Enter Employee ID To Be Searched");

        Employee e = null;
        int ID = StartUI.getAValidNumberFromUser("Enter A Valid Employee ID");
        if (ID > 0) {
            e = executiveService.searchEmployeeByID(ID);
        }

        if (e != null) {
            printEmployeeObject(e);
        } else {
            System.out.println("Employee not found in the database.");
        }
    }

    //  3.2 - Assign Project To Employee
    private static void assignProjectToManager(ExecutiveServiceImplementation executiveService, int executiveID) {

        System.out.println("***** Assign Project To Manager *****");

        // Executive Can Allocate Employees For Projects
        // Of only which they are in charge of

        ArrayList<User> list = executiveService.viewAllUnallocatedManagers(executiveID);
        if (list != null) {
            Iterator<User> iterator = list.iterator();
            System.out.println("<<--  List Of Unallocated Managers    -->>");
            while (iterator.hasNext()) {
                User user = iterator.next();
                System.out.println("{ Name : " + user.getName() + ", ID : " + user.getUserID());
            }
        }

        System.out.println("Enter Manager ID You want to allocate in your Project");
        int managerID = StartUI.getAValidNumberFromUser("Enter A Valid Manager ID");

        //  Allocate the project
        boolean status = executiveService.assignProjectToManager(executiveID, managerID);
        if (status) {
            System.out.println("Records Updated Successfully");
        } else {
            System.out.println("Records Not Updated Successfully");
        }
    }

    //  3.2 - View All Requests
    private static void viewAllRequisitionRequests(ExecutiveServiceImplementation executiveService, int executiveID) {
        System.out.println("*****   View All Open Requisition Requests    *****\n");
        getRequest(executiveService, executiveID, IRSValues.REQUISITION_REQUEST_OPEN);
    }

    //  3.3 - Give Suggestion On Basis Of Requests
    private static void giveSuggestionForRequest(ExecutiveServiceImplementation executiveService, int executiveID) {
        System.out.println("*****   Giving Suggestions   *****");

        // SHOW OPEN REQUESTS
        getRequest(executiveService, executiveID, IRSValues.REQUISITION_REQUEST_OPEN);

        System.out.println("Enter The Request ID For which you want to suggest");

        int requisitionRequestID = StartUI.getAValidNumberFromUser("Enter A Correct Requisition Request");

        System.out.println("Press 1 If You want to search employees");
        String choice = StartUI.getInputFromBufferedReader();
        if (choice.equals("1")) {
            // SEARCH EMPLOYEES
            searchEmployee(executiveService);
        }

        System.out.println("Enter the Employee ID For 2 Employees ");

        int emp1ID = StartUI.getAValidNumberFromUser("Enter Correct ID For Employee 1");
        int emp2ID = StartUI.getAValidNumberFromUser("Enter Correct ID For Employee 2");

        String combinedEmployees = emp1ID + " " + emp2ID;

        boolean done = executiveService.giveSuggestion(executiveID, requisitionRequestID, combinedEmployees);

        if (done) {
            System.out.println("Suggestion Raised");
        } else {
            System.out.println("Suggestion Not Raised");
        }
    }

    //  3.4 - Generate Reports
    private static void generateReports(ExecutiveServiceImplementation executiveService, int executiveID) {

        System.out.println("*****   Generate Reports    *****\n");

        System.out.println("Press 1 To Get All Closed Requests");
        System.out.println("Press 2 To Get All Closed Request By Some Date");
        System.out.println("Press 3 To Get All Open Request");
        System.out.println("Press 4 To Get All Open Request By Some Date");
        System.out.println("Press -1 To Go Back To Previous Section");

        String executiveInput = StartUI.getInputFromBufferedReader();
        Date date;

        switch (executiveInput) {
            case "1":
                Log.i(TAG, "Get All Closed Requests");
                getRequest(executiveService, executiveID, IRSValues.REQUISITION_REQUEST_CLOSED);
                break;

            case "2":
                date = getDateFromUserAndParseIt();
                Log.i(TAG, "Get All Closed Requests By " + date);
                getRequest(executiveService, executiveID, IRSValues.REQUISITION_REQUEST_CLOSED, date);
                break;

            case "3":
                Log.i(TAG, "Get All Open Requests");
                getRequest(executiveService, executiveID, IRSValues.REQUISITION_REQUEST_OPEN);
                break;

            case "4":
                date = getDateFromUserAndParseIt();
                Log.i(TAG, "Get All Open Requests By " + date);
                getRequest(executiveService, executiveID, IRSValues.REQUISITION_REQUEST_OPEN, date);
                break;

            case "-1":
                return;

            default:
                System.out.println("Invalid Input, Try Again");
                break;
        }
        generateReports(executiveService, executiveID);
    }

    private static Date getDateFromUserAndParseIt() {

        System.out.println("Enter Date In Format DD-MM-YYYY");
        String inputStringDate = StartUI.getInputFromBufferedReader();

        SimpleDateFormat format = new SimpleDateFormat("DD-MM-YYYY");
        java.util.Date parsedDate = null;
        java.sql.Date sqlDate = null;
        try {
            parsedDate = format.parse(inputStringDate);
            sqlDate = new java.sql.Date(parsedDate.getTime() + 86400000);
        } catch (Exception e) {
            System.out.println("Invalid Date Format");
            e.printStackTrace();
        }
        return sqlDate;
    }

    private static void getRequest(ExecutiveServiceImplementation executiveService, int executiveID, int requestCode, Date date) {

        // Passing This To View All Open Requests By User Specified Date
        ArrayList<RequisitionRequest> listOfRequests = executiveService.viewAllRequisitionRequests(executiveID, requestCode, date);

        Iterator<RequisitionRequest> iterator = listOfRequests.iterator();

        while (iterator.hasNext()) {
            RequisitionRequest request = iterator.next();
            ManagerUI.printRequestObject(request);
        }
    }

    private static void getRequest(ExecutiveServiceImplementation executiveService, int executiveID, int requestCode) {
        ArrayList<RequisitionRequest> listOfRequests = executiveService.viewAllRequisitionRequests(
                executiveID,
                requestCode,
                // Passing This To View All Open Requests By Today
                new java.sql.Date(new java.util.Date(System.currentTimeMillis() + 86400000).getTime())
        );

        Iterator<RequisitionRequest> iterator = listOfRequests.iterator();

        while (iterator.hasNext()) {
            RequisitionRequest request = iterator.next();
            ManagerUI.printRequestObject(request);
        }
    }

    static void printEmployeeObject(Employee e) {

        /*
         * Checking For No Data
         */

        if (e == null) {
            System.out.println("No Data Found For The Employee");
            return;
        }

        /*
         * Else, Print Data
         */

        System.out.println("    Employee Details:");
        System.out.println("    {");
        System.out.println(
                "       ID : " + e.getEmployeeID() + ",\n" +
                        "       Name : " + e.getEmployeeName() + ",\n" +
                        "       Project ID : " + e.getEmployeeProjectID() + ",\n" +
                        "       Domain : " + e.getEmployeeDomain() + ",\n" +
                        "       Skills : " + e.getEmployeeSkills() + ",\n" +
                        "       Experience : " + e.getYearsOfExperience() + ",\n" +
                        "       Allocation Status : " + (e.getEmployeeStatus() == IRSValues.ALLOCATED_IN_PROJECT ? "Allocated" : "Unallocated")
        );
        System.out.println("    }\n");
    }
}
