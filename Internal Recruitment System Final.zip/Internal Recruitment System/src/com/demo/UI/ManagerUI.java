package com.demo.UI;

import com.demo.Model.RequisitionRequest;
import com.demo.Model.RequisitionSuggestions;
import com.demo.Model.User;
import com.demo.Service.Implementation.ExecutiveServiceImplementation;
import com.demo.Service.Implementation.ResourceManagerServiceImplementation;
import com.demo.Util.IRSValues;
import com.demo.Util.Log;

import java.util.ArrayList;
import java.util.Iterator;

public class ManagerUI {
    private static final String TAG = "ManagerUI : ";
    public static void loginAsResourceManager(User loggedInUser) {

        // ================================================================
        // =                                                              =
        // =          3. When User is Logged In As RMG Executive          =
        // =                                                              =
        // ================================================================

        StartUI.printSymbols();
        StartUI.greetUser(loggedInUser);
        int managerID = loggedInUser.getUserID();

        System.out.println("Press 1 To Raise New Requisition Request");
        System.out.println("Press 2 To See Executive Suggestions For " + loggedInUser.getName());
        System.out.println("Press 3 To Accept / Reject the Suggestions");
        System.out.println("Press 4 To Update Project Allocation For Employee");
        System.out.println("Press 5 To See Reports");
        System.out.println("Press -1 To Go Logout");
        System.out.println();

        // This can be lazily instantiated from the methods, following Singleton Design Pattern
        ResourceManagerServiceImplementation resourceManagerService = new ResourceManagerServiceImplementation();

        String rmgInput = StartUI.getInputFromBufferedReader();

        switch (rmgInput) {
            case "1":
                Log.i(TAG, "Raise New Requisition Request");
                raiseNewRequisitionRequest(resourceManagerService, managerID);
                break;

            case "2":
                Log.i(TAG, "View Executive Suggestions");
                viewExecutivesSuggestions(resourceManagerService, managerID);
                break;

            case "3":
                Log.i(TAG, "Accept Reject Suggestions");
                acceptRejectSuggestions(resourceManagerService, managerID);
                break;

            case "4":
                Log.i(TAG, "Update Project Allocation For Employee");
                updateProjectAllocationForEmployee(resourceManagerService, managerID);
                break;

            case "5":
                Log.i(TAG, "Generate Reports For Resource Manager");
                generateReportsForResourceManager(resourceManagerService, loggedInUser);
                break;

            case "-1":
                return;

            default:
                System.out.println("Enter Valid Input, Please Try Again");
                break;
        }

        //Re-run This Menu
        loginAsResourceManager(loggedInUser);

    }

    // ====================================================================
    // =                  Resource Manager Functionality                  =
    // ====================================================================

    // 2.1 - Raise New Requisition Request - DONE - WORKING
    private static void raiseNewRequisitionRequest(ResourceManagerServiceImplementation resourceManagerService, int managerID) {

        /*
         * Get Vacancy, Skills, Domain, Number of Required People at moment
         */

        StartUI.printSymbols();
        System.out.println("***** Raising Requisition Request *****");

        System.out.println("Enter Vacancy Of People In Numbers");
        int vacancy = StartUI.getAValidNumberFromUser("Enter Valid Vacancy");
        if (vacancy < 0) {
            return;
        }

        System.out.println("Enter The Skills");
        String skills = StartUI.getInputFromBufferedReader().toLowerCase();

        // Capitalizing First Letter of Skill
        skills = skills.substring(0, 1).toUpperCase() + skills.substring(1);

        System.out.println("Enter Domain Name");
        String domainName = StartUI.getAValidNameFromUser("Enter A Valid Domain Name");

        System.out.println("Enter Number Of People Required");
        int numberOfPeopleRequired = StartUI.getAValidNumberFromUser("Enter A Valid Number Of Required People");

        // Building The Requisition Request Object
        RequisitionRequest.Builder builder = new RequisitionRequest.Builder();
        builder
                .resourceManagerID(managerID)
                .vacancy(vacancy)
                .skillsAsString(skills)
                .domainName(domainName)
                .numberOfPeopleRequired(numberOfPeopleRequired);

        RequisitionRequest newRequisitionRequest = builder.build();

        // Calling Service Layer For Processing
        int requisitionRequestID = resourceManagerService.raiseRequisitionRequest(newRequisitionRequest);

        // Checking For Returning Values
        if (requisitionRequestID != 0) {
            System.out.println("Requisition Request Raised");
        } else {
            System.out.println("Failed To Raise Requisition Request");
        }
    }

    // 2.2 - View Suggestion Made By Executives - DONE
    private static void viewExecutivesSuggestions(ResourceManagerServiceImplementation resourceManagerService, int managerID) {

        System.out.println("***** View Executive Suggestions *****");
        System.out.println(
                "Enter 1. To View All OPEN suggestions\n" +
                        "Enter 2. To View All ACCEPTED suggestions\n" +
                        "Enter 3. To View All REJECTED suggestions\n" +
                        "Enter 4. To View All suggestions\n" +
                        "Enter -1 To Go Back"
        );

        String inputCase = StartUI.getInputFromBufferedReader();
        switch (inputCase) {
            case "1":

                // ================================================================
                // =      			List Of All Open Suggestions     		      =
                // ================================================================

                System.out.println("<<-- ALL OPEN SUGGESTIONS -->>");
                showSuggestion(resourceManagerService, managerID, IRSValues.REQUISITION_SUGGESTION_SUGGESTED);
                break;

            case "2":

                // ================================================================
                // =      		    List Of All Accepted Suggestions     		  =
                // ================================================================

                System.out.println("<<-- ALL ACCEPTED SUGGESTIONS -->>");
                showSuggestion(resourceManagerService, managerID, IRSValues.REQUISITION_SUGGESTION_ACCEPTED);
                break;

            case "3":

                // ================================================================
                // =      		    List Of All Rejected Suggestions     		  =
                // ================================================================

                System.out.println("<<-- ALL REJECTED SUGGESTIONS -->>");
                showSuggestion(resourceManagerService, managerID, IRSValues.REQUISITION_SUGGESTION_REJECTED);
                break;

            case "4":

                // ================================================================
                // =      				List Of All Suggestions     			  =
                // ================================================================

                System.out.println("ALL SUGGESTIONS");
                showSuggestion(resourceManagerService, managerID, IRSValues.REQUISITION_SUGGESTION_ACCEPTED);
                showSuggestion(resourceManagerService, managerID, IRSValues.REQUISITION_SUGGESTION_REJECTED);
                showSuggestion(resourceManagerService, managerID, IRSValues.REQUISITION_SUGGESTION_SUGGESTED);
                break;

            case "-1":
                // Going Back To Login As Manager
                return;

            default:
                System.out.println("Please Enter A Valid Input");
        }

        viewExecutivesSuggestions(resourceManagerService, managerID);

    }

    // 2.3 - Accept / Reject Suggestions Made By Executives - DONE
    private static void acceptRejectSuggestions(ResourceManagerServiceImplementation resourceManagerService, int managerID) {

        System.out.println("*****   Accept / Reject Suggestions, You have the following suggestions    *****");
        viewExecutivesSuggestions(resourceManagerService, managerID);

        System.out.println("Enter The Requisition Suggestion ID");
        int requisitionSuggestionID = StartUI.getAValidNumberFromUser("Enter Correct Requisition Suggestion ID");

        System.out.println("Please Enter 'Accept' To Accept This Suggestion");
        System.out.println("Please Enter 'Reject' To Reject This Suggestion");

        int choice = 399;
        String inputChoice = StartUI.getInputFromBufferedReader();
        if (inputChoice.equals("Accept")) {
            choice = 400;
        } else if (inputChoice.equals("Reject")) {
            choice = 401;
        }

        // Calling The Service Layer, Passing The Option, Getting  A Boolean in return if executed successfully
        if (resourceManagerService.acceptRejectSuggestions(managerID, requisitionSuggestionID, choice)) {
            if (choice == IRSValues.REQUISITION_SUGGESTION_ACCEPTED) {
                System.out.println("Suggestion Accepted");
            } else if (choice == IRSValues.REQUISITION_SUGGESTION_REJECTED) {
                System.out.println("Suggestion Rejected");
            }
        }
    }

    // 2.4 - Update Project Allocation For Employee - DONE - WORKING
    private static void updateProjectAllocationForEmployee(ResourceManagerServiceImplementation resourceManagerService, int managerID) {

        System.out.println("*****   Updating Project Allocation For Employee    *****");
        System.out.println("Enter EmployeeID");
        int empID = StartUI.getAValidNumberFromUser("Enter A Valid Employee ID");

        if (resourceManagerService.updateProjectForEmployee(managerID, empID)) {
            System.out.println("Details Updated Successfully");
        } else {
            System.out.println("Failed To Update Any Details");
        }
    }

    // 2.6 - Generate Reports For Resource Manager - DONE - PARTIALLY WORKING
    private static void generateReportsForResourceManager(ResourceManagerServiceImplementation resourceManagerService, User loggedInManager) {

        System.out.println("***********************************************************");
        System.out.println("    Request Raised By " + loggedInManager.getName());
        System.out.println("***********************************************************");

        // ================================================================
        // =      			List Of All Open Requests     				  =
        // ================================================================

        StartUI.printSpaces();
        System.out.println("*******   ALL OPEN REQUESTS   *******");
        showRequests(resourceManagerService, loggedInManager.getUserID(), IRSValues.REQUISITION_REQUEST_OPEN);

        // ================================================================
        // =      			List Of All Closed Requests     		      =
        // ================================================================

        StartUI.printSpaces();
        System.out.println("*******     ALL CLOSED REQUESTS   *******");
        showRequests(resourceManagerService, loggedInManager.getUserID(), IRSValues.REQUISITION_REQUEST_CLOSED);

    }

    // 2.6.1 Show Requests According to Type - DONE
    private static void showRequests(ResourceManagerServiceImplementation resourceManagerService, int managerID, int requestCode) {
        getAndDisplayRequests(resourceManagerService, managerID, requestCode);
    }

    // 2.6.2 Show Suggestions According to Type - DONE
    private static void showSuggestion(ResourceManagerServiceImplementation resourceManagerService, int managerID, int suggestionsCode) {

        ArrayList<RequisitionSuggestions> requisitionSuggestions = resourceManagerService.viewSuggestionsMadeByExecutive(managerID, suggestionsCode);

        // Checking If No Data is Fetched
        if (requisitionSuggestions == null) {
            System.out.println("No Suggestions Found In Database");
            return;
        }

        Iterator<RequisitionSuggestions> iterator = requisitionSuggestions.iterator();
        System.out.println("        {");
        while (iterator.hasNext()) {
            RequisitionSuggestions suggestion = iterator.next();
            System.out.println("\n" +
                    "           Suggestion ID : " + suggestion.getRequisitionSuggestionID() + ",\n" +
                    "           For Project ID : " + suggestion.getSuggestedProjectID() + ",\n" +
                    "           Suggested Employee ID : " + suggestion.getSuggestedEmployeeID() + "\n"
            );
            String[] listOfEmployee = suggestion.getSuggestedEmployeeID().split(" ");
            ExecutiveServiceImplementation executiveServiceImplementation = new ExecutiveServiceImplementation();
            for (int i = 0; i < listOfEmployee.length; i++) {
                ExecutiveUI.printEmployeeObject(executiveServiceImplementation.searchEmployeeByID(Integer.valueOf(listOfEmployee[i])));
            }
        }
        System.out.println("        }");
    }

    // 2.6.3 Support Method For Manager Functionality
    private static void getAndDisplayRequests(ResourceManagerServiceImplementation resourceManagerService, int managerID, int requestCode) {

        ArrayList<RequisitionRequest> listOfAllRequests = resourceManagerService.viewAllRequests(managerID, requestCode);

        if (listOfAllRequests == null) {
            System.out.println("No Records Found");
            return;
        }

        // Calling Printing Method For This Request Object

        Iterator<RequisitionRequest> iterator = listOfAllRequests.iterator();
        while (iterator.hasNext()) {
            RequisitionRequest request = iterator.next();
            printRequestObject(request);
        }
    }

    // 2.6.4 Support Method For Manager Functionality
    static void printRequestObject(RequisitionRequest request) {
        System.out.println("[ Request " + request.getRequsitionID() + " ]");

        System.out.println("   { \n" +
                "       Domain Name : " + request.getDomainName() + ",\n" +
                "	    Project ID : " + request.getProjectID() + ",\n" +
                "	    Vacancy Of People : " + request.getVacancy() + ",\n" +
                "	    Required People : " + request.getNumberOfPeopleRequired() + ",\n" +
                "	    Skills Required : " + request.getSkillsAsString() + ",\n" +
                "	    Request Status : " + request.getRequestStatus() + ",\n" +
                "	    Request Open Date : " + request.getDateCreated() + ",\n" +
                "	    Request Close Date : " + request.getDateClosed() + "\n   }"
        );
    }
}
