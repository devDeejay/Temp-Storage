package com.demo.Service.Interface;

import com.demo.Model.User;

public interface UserServiceInterface {
    public User loginUser(User newUser);
}
