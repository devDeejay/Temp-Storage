package com.demo.Service.Implementation;

import com.demo.DAO.Implementation.ManagerDAOImplementation;
import com.demo.Model.RequisitionSuggestions;
import com.demo.Model.RequisitionRequest;
import com.demo.Service.Interface.ResouceManagerInterface;

import java.util.ArrayList;

public class ResourceManagerServiceImplementation implements ResouceManagerInterface {
    private static final String TAG = "ManagerService : ";
	ManagerDAOImplementation resourceManagerDAO = new ManagerDAOImplementation();
	
    @Override
    public int raiseRequisitionRequest(RequisitionRequest request) {
        return resourceManagerDAO.raiseRequisitionRequestInDatabase(request);
    }

    @Override
    public boolean acceptRejectSuggestions(int managerID, int requisitionSuggestionID, int choice) {
        // Calling method in DAO Layer
        return resourceManagerDAO.acceptRejectSuggestionsInDatabase(managerID, requisitionSuggestionID, choice);
    }

    @Override
    public boolean updateProjectForEmployee( int managerID, int employeeID) {
        // Calling method in DAO Layer
        return resourceManagerDAO.assignProjectToEmployee(managerID, employeeID);
    }

	@Override
	public ArrayList<RequisitionRequest> viewAllRequests(int managerID, int choice) {
		// TODO Auto-generated method stub
		return resourceManagerDAO.viewAllRequestsMade(managerID, choice);

	}

	@Override
	public ArrayList<RequisitionSuggestions> viewSuggestionsMadeByExecutive(int managerID, int suggestionCode) {
		return resourceManagerDAO.viewSuggestionsMadeByExecutiveFromDatabase(managerID, suggestionCode);
	}
}
