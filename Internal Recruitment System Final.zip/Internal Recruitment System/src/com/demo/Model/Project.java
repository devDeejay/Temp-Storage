package com.demo.Model;

public class Project {
    int projectID;
    String projectName;
    String managerName;
}
