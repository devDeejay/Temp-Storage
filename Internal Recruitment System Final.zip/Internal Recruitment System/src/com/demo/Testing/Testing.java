package com.demo.Testing;

import com.demo.Model.RequisitionRequest;
import com.demo.Model.User;
import com.demo.Service.Implementation.AdminServiceImplementation;
import com.demo.Service.Implementation.ResourceManagerServiceImplementation;
import com.demo.UI.ManagerUI;
import com.demo.UI.StartUI;
import com.demo.Util.IRSValues;
import org.junit.Test;
import org.omg.CORBA.Request;

import static org.junit.Assert.assertEquals;

public class Testing {
/*
    int resourceManagerID = request.getResourceManagerID();
    int vacancy = request.getVacancy();
    int numberOfPeopleRequired = request.getNumberOfPeopleRequired();
    String skillsAsString = request.getSkillsAsString();
    String domainName = request.getDomainName();
    int requestStatus = IRSValues.REQUISITION_REQUEST_OPEN;*/

    @Test
    public void raiseRequest()  {
        RequisitionRequest.Builder requestBuilder = new RequisitionRequest.Builder();
        requestBuilder.resourceManagerID(1000)
                .vacancy(2)
                .numberOfPeopleRequired(2).skillsAsString("Level 2")
                .domainName("Java")
                .requestStatus(IRSValues.REQUISITION_REQUEST_OPEN);

        RequisitionRequest requisitionRequest = requestBuilder.build();

        assertEquals(1, new ResourceManagerServiceImplementation().raiseRequisitionRequest(requisitionRequest));
    }


    // Testing For Login

    @Test
    public void testAdminLoginCheck()  {
        User.Builder userBuilder = new User.Builder();
        userBuilder.username("DJ").password("D1J").userID(199).name("Dhananjay Trivedi");
        User user = userBuilder.build();

        assertEquals(user, StartUI.checkUserCredentials(user));
    }

    // Testing For Login

    @Test
    public void modifyUser()  {
        User.Builder userBuilder = new User.Builder();
        userBuilder.username("dhaman").password("dhaman").userID(1001).name("Dhama Trivedi").userGrade(101);
        User user = userBuilder.build();

        assertEquals(true, new AdminServiceImplementation().modifyUser(user));
    }


}
