package com.demo.Exceptions;

import com.demo.Util.Log;

public class UserException extends Exception {

    private static final String TAG = "User Exception";

    public UserException(String errorMessage, String message) {

        /*
         * A custom error message will be displayed to the user
         */

        System.out.println(message);

        /*
         * A real error message will be logged for the developers
         */

        Log.e(TAG, errorMessage);
    }
}
