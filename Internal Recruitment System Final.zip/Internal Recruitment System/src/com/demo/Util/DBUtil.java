package com.demo.Util;

import com.demo.Exceptions.UserException;

import java.sql.Connection;
import java.sql.DriverManager;

//	==========================================
//	=                                        =
//	=  	  		DBUtil.java Class     		 =
//	=   Following Singleton Design Pattern   =  // Singleton will cause problems for concurrent users
//	=                                        =
//	==========================================


public class DBUtil {

    //	Declaring Following Fields as 'Volatile'
    //	So as to make them Thread Safe

    private static volatile DBUtil dbUtilInstance = null;
    private volatile Connection connectionInstance = null;

    private DBUtil() {
        // TODO Auto-generated constructor stub
    }

    // 	GetInstance Method For DBUtil
    public static DBUtil getInstance() {
        try {

            if (dbUtilInstance == null) {

                // Only one user will be able to interact with the database at a time
                // Cos we are using same object for every user

                synchronized (DBUtil.class) {
                    if (dbUtilInstance == null) {
                        dbUtilInstance = new DBUtil();
                    }
                }
            }
            return dbUtilInstance;
        } catch (Exception e) {
            try {
                throw new UserException(e.getMessage(), "Cannot Connect To Database");
            } catch (UserException userexception) {
                return null;
            }
        }
    }

    // GetInstance Method For Connection

    public Connection getConnection() {
        if (connectionInstance == null) {
            synchronized (DBUtil.class) {
                if (connectionInstance == null) {
                    try {
                        connectionInstance = DriverManager.getConnection(IRSValues.DB_URL,
                                IRSValues.DB_USERNAME, IRSValues.DB_PASSWORD);
                    } catch (Exception e) {

                        // TODO: Throw Some Exception Here

                        System.out.println(e.getMessage());
                        System.out.println("Failed To Instantiate Connection Object");
                        connectionInstance = null;
                    }
                }
            }
        }
        return connectionInstance;
    }

    // 	Method For Closing The Connection

    public boolean closeConnection() {
        boolean status = false;
        if (connectionInstance != null) {
            try {
                connectionInstance = null;
                status = true;
            } catch (Exception e) {

                // TODO: Throw Some Exception Here

                System.out.println("Failed To Close Connection Object");
            }
        }
        return status;
    }
}
