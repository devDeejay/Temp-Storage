package com.demo.Util;

public interface IRSValues {
    int RESOURCE_MANAGER = 101;
    int EXECUTIVE = 102;
    int ADMIN = 103;

    int ALLOCATED_IN_PROJECT = 201;
    int UNALLOCATED_IN_ANY_PROJECT = 202;

    int REQUISITION_REQUEST_OPEN = 300;
    int REQUISITION_REQUEST_CLOSED = 301;

    int REQUISITION_SUGGESTION_ACCEPTED = 400;
    int REQUISITION_SUGGESTION_REJECTED = 401;
    int REQUISITION_SUGGESTION_SUGGESTED = 402;

    // Database Configuration

    String DB_URL = "jdbc:oracle:thin:@10.219.34.3:1521:orcl";
    String DB_USERNAME = "trg230";
    String DB_PASSWORD = "training230";


}
