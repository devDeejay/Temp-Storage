package Data_Structures.LinkedList;

public class LinkedLists_Main {
}
