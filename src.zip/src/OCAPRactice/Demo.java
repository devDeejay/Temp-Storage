package OCAPRactice;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

class Demo {
    float f;

    public static void main(String[] args) {
        System.out.println  ("gg");

    }
}
